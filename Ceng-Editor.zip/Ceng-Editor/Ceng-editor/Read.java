import enigma.console.TextAttributes;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

public class Read {
    public static MultiLinkedList MLL = new MultiLinkedList();
    public static int[][] wordcount = new int[20][1000];
    public static int  paragraphnumber = 0;


    public Read() throws FileNotFoundException {//We throw the paragraphs and letters in the txt into the MLL

        int count = 0;
        int count2 = 1;
        int k = 0;

        Scanner sc = new Scanner(new File("random2.txt"));
        int paragraphcount = 1;
        MLL.addParagraph(paragraphcount);
        while (sc.hasNextLine()) {
            char letter;
            String words = "";
            words = sc.nextLine();
            if (words == "") {
                count2 = 1;
                paragraphcount++;
                MLL.addParagraph(paragraphcount);
                k = 0;
            } else {
                for (int i = 0; i < words.length(); i++) {
                    letter = words.charAt(i);
                    if(letter==' '|| letter=='.'|| letter==','|| letter==':'||letter==';'|| letter=='!'|| letter=='?' || letter=='-' || letter=='*'||letter=='+'
                            || (letter>='A' && letter<='Z')||(letter>='a'&&letter<='z')
                            ||(letter>='0'&&letter<='9')){
                        if (count2 % 60 == 0) {
                            MLL.addLetter(paragraphcount, letter);
                            count2++;
                        } else {
                            MLL.addLetter(paragraphcount, letter);
                            count2++;
                        }
                        if (letter != ' ') {
                            count++;
                        } else {
                            wordcount[paragraphcount - 1][k] = count;
                            count = 0;
                            k++;
                        }
                    }
                }
                wordcount[paragraphcount - 1][k] = count;
                k++;
                count = 0;
            }
        }
    }
    public void ConsoleClear() {
        for (int i = 1; i <= 20; i++) {
            Editor.cnt.setCursorPosition(1,i);
            System.out.println("                                                            ");
        }
    }

    public void wordCount() {//A method that ensures words are not split at the end of the line and allows us to write the txt to the screen

        ConsoleClear();
        int px = 0;
        int py = 0;
        ParagraphNode temp = MLL.head;
        charNode right = temp.getRightlink();
        boolean first = true;
        int wcount = 0;
        int c2 = 1;
        int x = 0;
        int y = 0;
        int k = 0;
        boolean flag = true;
        for (int i = 0; i < 20; i++) {
            if(flag == false)
                break;
            if(Editor.pagedown == true) {
                c2 = 1;
                flag = true;
                while(temp != null) {
                    while(temp.getParagraphNumber() != paragraphnumber) {
                        temp = temp.getDownlink();
                        if(temp.getParagraphNumber() == paragraphnumber)
                            break;
                    }
                    if(temp.getParagraphNumber() == paragraphnumber)
                        break;
                }
                if(temp != null)
                    right = temp.getRightlink();

            }
            if(flag == false)
                break;
            wcount = 0;
            first = true;
            for (int j = 0; j < 100; j++) {
                wcount += (wordcount[i][j] + 1);
                if (wcount + (wordcount[i][j + 1] + 1) >= 60) {
                    x = i;
                    y = j + 1;
                    int hmc = wcount;
                    int count = 0;
                    while (count != hmc && right != null) {
                        Editor.cnt.setCursorPosition(count + 1, c2);
                        if(right != null) {
                            right.setLinenumber(right.getLinenumber() +c2);
                        }
                        right.setPx(count+1);
                        right.setPy(c2);
                        System.out.print(right.getLetter());
                        count++;
                        right = right.getRightlink();
                        if(right != null) {
                            right.setLinenumber( c2);
                        }
                        Editor.cursor.setPx(px);
                        Editor.cursor.setPy(py);
                        px = count+1;
                        py = c2;
                    }
                    while (i != 0 && count != hmc) {
                        Editor.cnt.setCursorPosition(count + 1, c2);
                        if(right != null) {
                            right.setLinenumber(c2);
                        }
                        if (first == true) {
                            if (temp == null) {
                                break;
                            } else {
                                temp = temp.getDownlink();
                                if (temp == null)
                                    break;
                                right = temp.getRightlink();
                                first = false;
                            }
                        }
                        if (right == null || temp == null)
                            break;
                        System.out.print(right.getLetter());
                        count++;
                        if(right != null)
                            right.setLinenumber(c2);
                        right = right.getRightlink();
                        Editor.cursor.setPx(px);
                        Editor.cursor.setPy(py);
                        px = count+1;
                        py = c2;
                    }
                    wcount = 0;
                    c2++;
                    if(c2 > 20) {
                        if(temp != null) {
                            paragraphnumber = temp.getParagraphNumber();

                        }
                        flag = false;
                        break;
                    }

                    if(flag == false)
                        break;
                }
            }
        }
    }
}