public class EditorTest {
    public static void main(String[] args) throws Exception {
        Editor myEditor = new Editor();
    }
}