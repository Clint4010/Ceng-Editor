import enigma.console.TextAttributes;

import java.awt.*;

public class DisplayScreen {

    public TextAttributes backgrounddarkgray = new TextAttributes(Color.DARK_GRAY, Color.DARK_GRAY);
    public TextAttributes cyan=new TextAttributes(Color.CYAN,Color.CYAN);
    public TextAttributes magenta=new TextAttributes(Color.MAGENTA,Color.MAGENTA);
    public TextAttributes lightgray=new TextAttributes(Color.LIGHT_GRAY,Color.LIGHT_GRAY);
    public TextAttributes gray=new TextAttributes(Color.GRAY,Color.GRAY);
    public TextAttributes pink=new TextAttributes(Color.PINK,Color.PINK);
    public TextAttributes yellow=new TextAttributes(Color.YELLOW,Color.YELLOW);
    public TextAttributes white=new TextAttributes(Color.WHITE,Color.WHITE);
    public TextAttributes orange=new TextAttributes(Color.ORANGE,Color.ORANGE);
    public TextAttributes blue=new TextAttributes(Color.BLUE,Color.BLUE);
    public TextAttributes red=new TextAttributes(Color.RED,Color.RED);
    public TextAttributes green=new TextAttributes(Color.GREEN,Color.GREEN);


    public void displayScreen(){
        Editor.cn.getTextWindow().setCursorPosition(0, 0);
        Editor.cn.getTextWindow().output("+----+----+----+----+----+----+----+----+----+----+----+----++",gray);
        Editor.cn.getTextWindow().setCursorPosition(0, 21);
        Editor.cn.getTextWindow().output("+----+----+----+----+----+----+----+----+----+----+----+----++",gray);

        for (int i = 1; i < 21; i++) {
            if (i % 5 == 0) {
                Editor.cn.getTextWindow().setCursorPosition(0, i);
                Editor.cn.getTextWindow().output("+",gray);
                Editor.cn.getTextWindow().setCursorPosition(61, i);
                Editor.cn.getTextWindow().output("+",gray);
            } else {
                Editor.cn.getTextWindow().setCursorPosition(0, i);
                Editor.cn.getTextWindow().output("|",gray);
                Editor.cn.getTextWindow().setCursorPosition(61, i);
                Editor.cn.getTextWindow().output("|",gray);
            }
        }
        Editor.cn.getTextWindow().setCursorPosition(66,2);
        Editor.cn.getTextWindow().output("F1:Selection Start");
        Editor.cn.getTextWindow().setCursorPosition(66,3);
        Editor.cn.getTextWindow().output("F2:Selection End");
        Editor.cn.getTextWindow().setCursorPosition(66,4);
        Editor.cn.getTextWindow().output("F3:Cut");
        Editor.cn.getTextWindow().setCursorPosition(66,5);
        Editor.cn.getTextWindow().output("F4:Copy");
        Editor.cn.getTextWindow().setCursorPosition(66,6);
        Editor.cn.getTextWindow().output("F5:Paste");
        Editor.cn.getTextWindow().setCursorPosition(66,7);
        Editor.cn.getTextWindow().output("F6:Find");
        Editor.cn.getTextWindow().setCursorPosition(66,8);
        Editor.cn.getTextWindow().output("F7:Replace");
        Editor.cn.getTextWindow().setCursorPosition(66,9);
        Editor.cn.getTextWindow().output("F8:Next");
        Editor.cn.getTextWindow().setCursorPosition(66,10);
        Editor.cn.getTextWindow().output("F9:Align left");
        Editor.cn.getTextWindow().setCursorPosition(66,11);
        Editor.cn.getTextWindow().output("F10:Justify");
        Editor.cn.getTextWindow().setCursorPosition(66,12);
        Editor.cn.getTextWindow().output("F11:Load");
        Editor.cn.getTextWindow().setCursorPosition(66,13);
        Editor.cn.getTextWindow().output("F12:Save");
        Editor.cn.getTextWindow().setCursorPosition(66,15);
        Editor.cn.getTextWindow().output("Mode:");
        Editor.cn.getTextWindow().setCursorPosition(72,15);
        Editor.cn.getTextWindow().output(Editor.writing);
        Editor.cn.getTextWindow().setCursorPosition(66,17);
        Editor.cn.getTextWindow().output("Alignment:  Aligned Left");

    }
}

