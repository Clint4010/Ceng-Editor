public class charNode {

    private char letter;
    private charNode rightlink;
    private charNode leftlink;
    private ParagraphNode leftparagraphnodelink;
    private int linenumber;
    private int px;
    private int py;

    public charNode(char datatoAdd) {
        letter= datatoAdd;
        rightlink = null;
        leftlink = null;
        leftparagraphnodelink=null;
        linenumber = 1;
        px = 0;
        py = 0;
    }



    public int getPx() {
        return px;
    }



    public void setPx(int px) {
        this.px = px;
    }



    public int getPy() {
        return py;
    }



    public void setPy(int py) {
        this.py = py;
    }



    public int getLinenumber() {
        return linenumber;
    }

    public void setLinenumber(int linenumber) {
        this.linenumber = linenumber;
    }

    public char getLetter() { return letter; }

    public void setLetter(char letter) { this.letter = letter; }


    public charNode getRightlink() { return rightlink; }

    public void setRightlink(charNode rightlink) { this.rightlink = rightlink; }

    public charNode getLeftlink() { return leftlink; }

    public void setLeftlink(charNode leftlink) { this.leftlink = leftlink; }

    public ParagraphNode getLeftparagraphnodelink() {
        return leftparagraphnodelink;
    }

    public void setLeftparagraphnodelink(ParagraphNode leftparagraphnodelink) {
        this.leftparagraphnodelink = leftparagraphnodelink;
    }
}