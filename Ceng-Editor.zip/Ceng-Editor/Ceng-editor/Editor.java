import enigma.core.Enigma;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import enigma.console.TextAttributes;
import java.awt.Color;

public class Editor {

    public static enigma.console.Console cn = Enigma.getConsole("CENG EDITOR", 100, 30, 14);
    public static enigma.console.TextWindow cnt = cn.getTextWindow();
    public static TextAttributes att0 = new TextAttributes(Color.white, Color.black);  //foreground, background color
    public static TextAttributes att1 = new TextAttributes(Color.black, Color.white);
    public static Cursor cursor;
    public KeyListener klis;
    public int keypr;   // key pressed?
    public int rkey;    // key   (for press/release)
    public int rkeymod;      // key modifiers
    public int capslock = 0;   // 0:off    1:on
    public int insert = 0;
    public int selectionstart = 0;
    public int find = 0;
    public int backspace = 0;
    public static String writing = "Insert";
    public static String FindingWord;
    public static String ReplaceWord;
    public static boolean pageup;
    public static boolean pagedown;
    // -----------------------------------------------------------------------------


    Editor() throws Exception {   // --- Contructor
        DisplayScreen displayScreen = new DisplayScreen();
        displayScreen.displayScreen();
        Read myRead = new Read();
        FindingWord = "";
        ReplaceWord = "";
        pagedown = false;
        pageup = false;

        klis = new KeyListener() {
            public void keyTyped(KeyEvent e) {
            }

            public void keyPressed(KeyEvent e) {
                if (keypr == 0) {
                    keypr = 1;
                    rkey = e.getKeyCode();
                    rkeymod = e.getModifiersEx();
                    if (rkey == KeyEvent.VK_CAPS_LOCK) {
                        if (capslock == 0)
                            capslock = 1;
                        else capslock = 0;
                    }
                    if (rkey == KeyEvent.VK_INSERT) {
                        if (insert == 0) {
                            insert = 1;
                            if (insert == 1) {
                                writing = "Overwrite";
                                displayScreen.displayScreen();
                            }
                        } else {
                            insert = 0;
                            if (insert == 0) {
                                writing = "Insert   ";
                                displayScreen.displayScreen();
                            }
                        }
                    }
                    if (rkey == KeyEvent.VK_F1) {
                        if (selectionstart == 0) {
                            selectionstart = 1;
                        } else selectionstart = 0;
                    }
                    if (rkey == KeyEvent.VK_F2) {
                        selectionstart = 0;
                    }
                    if (rkey == KeyEvent.VK_F6) {
                        if (find == 0) {
                            find = 1;
                        } else find = 0;
                    }
                }
            }

            public void keyReleased(KeyEvent e) {
            }
        };
        cn.getTextWindow().addKeyListener(klis);
        // --------------------------------------------------------------------------

        int curtype;
        curtype = cnt.getCursorType();   // default:2 (invisible)       0-1:visible
        cnt.setCursorType(2);
        cn.setTextAttributes(att0);

        int px = 1;
        int py = 1;
        cursor = new Cursor(px, py);

        while (true) {

            if (keypr == 1) {

                if (rkey == KeyEvent.VK_LEFT && px > 1) {
                    Read.MLL.shiftingLeft(cursor);
                    myRead.wordCount();
                    px--;
                    cursor.setPx(px);
                    cursor.setPy(py);
                    if (px == 2) {
                        px = 58;
                        py--;
                    }
                }
                if (rkey == KeyEvent.VK_RIGHT && px < 61) {
                    if (selectionstart == 1) {
                        Read.MLL.shiftingRight(cursor, true);
                        myRead.wordCount();
                    } else {
                        Read.MLL.shiftingRight(cursor, false);
                        myRead.wordCount();
                    }
                    px++;
                    cursor.setPx(px);
                    cursor.setPy(py);
                    if (px == 60) {
                        px = 0;
                        py++;
                    }
                }
                if (rkey == KeyEvent.VK_UP && py > 1) {
                    Read.MLL.shiftingUp(cursor);
                    myRead.wordCount();
                    py--;
                    cursor.setPx(px);
                    cursor.setPy(py);
                }
                if (rkey == KeyEvent.VK_DOWN && py < 20) {
                    Read.MLL.shiftingDown(cursor);
                    myRead.wordCount();
                    py++;
                    cursor.setPx(px);
                    cursor.setPy(py);
                }
                if (rkey == KeyEvent.VK_BACK_SPACE && px > 1) {
                    Read.MLL.backSpaceChar(cursor);
                    myRead.wordCount();
                    px--;
                    cursor.setPx(px);
                    cursor.setPy(py);
                    if (px == 2) {
                        px = 58;
                        py--;
                    }
                }
                if (rkey == KeyEvent.VK_DELETE) {
                    Read.MLL.deleteChar(cursor);
                    myRead.wordCount();
                    px++;
                    cursor.setPx(px);
                    cursor.setPy(py);
                }
                if (rkey == KeyEvent.VK_ENTER && py < 19) {
                    py++;
                    myRead.MLL.Enter(cursor);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_SPACE) {
                    myRead.MLL.enteringCharr(cursor, ' ');
                    myRead.wordCount();
                    px++;
                    cursor.setPx(px);
                    cursor.setPy(py);
                }
                if (rkey == KeyEvent.VK_PAGE_UP) {
                    pagedown = false;
                    myRead.ConsoleClear();
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_PAGE_DOWN) {//PAGE-DOWN
                    pagedown = true;
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_F5) {
                    myRead.MLL.Paste(cursor);
                    myRead.wordCount();
                    Read.MLL.selected = "";
                    Editor.cnt.setCursorPosition(66, 19);
                    Editor.cnt.output("Selected:");
                    Editor.cnt.setCursorPosition(76, 19);
                    Editor.cnt.output(Read.MLL.selected);
                }
                if (rkey == KeyEvent.VK_F6) {  //find
                    cnt.setCursorPosition(66, 21);
                    System.out.println("Find: ");
                    cnt.setCursorPosition(72, 21);
                    FindingWord = cn.readLine();
                    myRead.MLL.Find(cursor, FindingWord);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_F7) {
                    cnt.setCursorPosition(66, 24);
                    System.out.println("Replace: ");
                    cnt.setCursorPosition(75, 24);
                    ReplaceWord = cn.readLine();
                    myRead.MLL.Replace(cursor, ReplaceWord, FindingWord);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_F8) {
                    myRead.MLL.Next(cursor);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_F11) {
                    cursor.setCursor('|');
                    myRead.MLL.addCursor(Editor.cursor);
                    myRead.wordCount();
                    px = cursor.getPx();
                    py = cursor.getPy();
                }
                if (rkey == KeyEvent.VK_F12) {
                    myRead.MLL.saved = true;
                    myRead.MLL.Save(myRead.MLL.saved);
                    cnt.setCursorPosition(30, 25);
                    cnt.output("SAVED!!");
                }
                if (rkey == KeyEvent.VK_F3) {
                    myRead.MLL.Cut(cursor);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_HOME) {
                    myRead.MLL.Home(cursor);
                    myRead.wordCount();
                }
                if (rkey == KeyEvent.VK_END) {
                    myRead.MLL.End(cursor);
                    myRead.wordCount();
                }

                cnt.setCursorPosition(cursor.getPx(), cursor.getPy());
                char rckey = (char) rkey;
                //        left          right          up            down
                if (rckey == '%' || rckey == '\'' || rckey == '&' || rckey == '(') {    // test without using VK (Virtual Keycode)
                    cnt.setCursorPosition(px, py);

                } else {
                    if (rckey >= '0' && rckey <= '9') {
                        if (insert != 1) {
                            Read.MLL.enteringCharr(cursor, rckey);
                            myRead.wordCount();
                            px++;
                            cursor.setPx(px);
                            cursor.setPy(py);
                            if (px >= 60) {
                                px = 1;
                                py++;
                            }
                        }
                        else{
                            px++;
                            if (px >= 60) {
                                px = 1;
                                py++;
                            }
                            cursor.setPx(px);
                            cursor.setPy(py);
                            writing = "Overwrite";
                            displayScreen.displayScreen();
                            Read.MLL.overwrite(cursor,rckey);
                            myRead.wordCount();
                        }
                    }
                    if (rckey >= 'A' && rckey <= 'Z') {
                        if (insert != 1) {
                            if (((rkeymod & KeyEvent.SHIFT_DOWN_MASK) > 0) || capslock == 1) {
                                Read.MLL.enteringCharr(cursor, rckey);
                                myRead.wordCount();
                                px++;
                            } else {
                                Read.MLL.enteringCharr(cursor, (char) (rckey + 32));
                                myRead.wordCount();

                            }
                        }
                        if (insert == 1) {
                            px++;
                            if (px >= 60) {
                                px = 1;
                                py++;
                            }
                            cursor.setPx(px);
                            cursor.setPy(py);
                            writing = "Overwrite";
                            displayScreen.displayScreen();
                            if (((rkeymod & KeyEvent.SHIFT_DOWN_MASK) > 0) || capslock == 1) {
                                Read.MLL.overwrite(cursor, rckey);
                                myRead.wordCount();
                                px++;
                            } else {
                                Read.MLL.overwrite(cursor, (char) (rckey + 32));
                                myRead.wordCount();
                            }
                        }
                        px++;
                        if (px >= 60) {
                            px = 1;
                            py++;
                        }
                    }
                    if ((rkeymod & KeyEvent.SHIFT_DOWN_MASK) == 0) {
                        if (rckey == '.' || rckey == ',' || rckey == '-') {
                            Read.MLL.enteringCharr(cursor, rckey);
                            myRead.wordCount();
                            px++;
                            /*System.out.print(rckey);*/
                        }
                        cursor.setPx(px);
                        cursor.setPy(py);
                    } else {
                        if (rckey == '.'){
                            if(insert!=1){
                                Read.MLL.enteringCharr(cursor, ':');
                                myRead.wordCount();
                                px++;
                                cursor.setPx(px);
                                cursor.setPy(py);
                                if (px >= 60) {
                                    px = 1;
                                    py++;
                                }
                            }
                            else{
                                px++;
                                if (px >= 60) {
                                    px = 1;
                                    py++;
                                }
                                cursor.setPx(px);
                                cursor.setPy(py);
                                writing = "Overwrite";
                                displayScreen.displayScreen();
                                Read.MLL.overwrite(cursor,':');
                            }
                        }
                        if (rckey == ',') {
                            if(insert!=1){
                                Read.MLL.enteringCharr(cursor, ';');
                                myRead.wordCount();
                                px++;
                                cursor.setPx(px);
                                cursor.setPy(py);
                                if (px >= 60) {
                                    px = 1;
                                    py++;
                                }
                            }
                            else{
                                px++;
                                if (px >= 60) {
                                    px = 1;
                                    py++;
                                }
                                cursor.setPx(px);
                                cursor.setPy(py);
                                writing = "Overwrite";
                                displayScreen.displayScreen();
                                Read.MLL.overwrite(cursor,';');
                            }
                        }
                    }
                }
                keypr = 0;    // last action
            }
            Thread.sleep(20);
        } //end of game loop
    }
}

