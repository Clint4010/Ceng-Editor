import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MultiLinkedList {

    public ParagraphNode head;
    public charNode tail;
    public String selected = "";//We will keep the word we selected in the selection operation
    public int count = 0;//We will keep the length of the word we selected in the selection operation.
    private String filename = "random2.txt";
    public static boolean saved;


    public MultiLinkedList() {
        head = null;
        tail = null;
        saved = false;
    }

    public void addParagraph(int dataToAdd) {
        if (head == null) {
            ParagraphNode newnode = new ParagraphNode(dataToAdd);
            head = newnode;
        } else {
            ParagraphNode temp = head;
            while (temp.getDownlink() != null) {
                temp = temp.getDownlink();
            }
            ParagraphNode newnode = new ParagraphNode(dataToAdd);
            temp.setDownlink(newnode);
            newnode.setUplink(temp);
        }
    }

    public void addLetter(int paragraph, char letter) {

        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            while (temp != null) {
                if (paragraph == temp.getParagraphNumber()) {
                    charNode temp2 = temp.getRightlink();
                    if (temp2 == null) {
                        charNode newnode = new charNode(letter);
                        temp.setRightlink(newnode);
                        newnode.setLeftparagraphnodelink(temp);
                        newnode.setLeftlink(null);
                    } else {
                        while (temp2.getRightlink() != null) {
                            temp2 = temp2.getRightlink();
                        }
                        charNode newnode = new charNode(letter);
                        tail = newnode;
                        temp2.setRightlink(tail);
                        tail.setLeftlink(temp2);//emindeğilim
                    }
                }
                temp = temp.getDownlink();
            }
        }
    }

    public void Save(boolean saved) {
        saved = true;
        ParagraphNode temp = head;
        charNode temp2 = null;
        File f = new File(filename);
        try {
            FileWriter writer = new FileWriter(f);
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (temp2.getRightlink() != null) {
                    writer.write(temp2.getLetter());
                    temp2 = temp2.getRightlink();
                }
                temp = temp.getDownlink();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addCursor(Cursor cursor) {//used to append cursor to end
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            while (temp.getDownlink() != null) {
                temp = temp.getDownlink();
            }
            charNode temp2 = temp.getRightlink();
            while (temp2.getRightlink() != null) {
                temp2 = temp2.getRightlink();
            }
            charNode newnode = new charNode(cursor.getCursor());
            temp2.setRightlink(newnode);
            newnode.setLeftlink(temp2);
        }
    }

    public void shiftingLeft(Cursor cursor) {
        boolean finding = false;//our variable to find the cursor
        boolean iscursorontheleft = false;//If the cursor is just to the right of the paragraphnode, it is held to allow paragraph replacement.
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            charNode temp4 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                if (temp2.getLetter() == cursor.getCursor()) {
                    iscursorontheleft = true;
                    break;
                }
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null) {
                        break;
                    }
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false)
                    temp = temp.getDownlink();
            }
            if (finding == true && iscursorontheleft != true) {
                char temp3 = temp2.getLetter();
                temp2.setLetter(cursor.getCursor());
                temp2 = temp2.getRightlink();
                if (temp2 != null) {
                    temp2.setLetter(temp3);
                }
            }
            if (iscursorontheleft == true && finding != true) {
                ParagraphNode temp3 = temp2.getLeftparagraphnodelink();
                if (temp3.getUplink() != null) {
                    temp3.setRightlink(temp2.getRightlink());
                    temp2.getRightlink().setLeftparagraphnodelink(temp3);
                    temp3 = temp3.getUplink();
                    temp2 = temp3.getRightlink();
                    while (temp2.getRightlink() != null) {
                        temp2 = temp2.getRightlink();
                    }
                    charNode newnode = new charNode(cursor.getCursor());
                    temp2.setRightlink(newnode);
                    newnode.setLeftlink(temp2);
                }
            }
        }
    }

    public void shiftingRight(Cursor cursor, Boolean Selection) {
        boolean finding = false;
        boolean iscursorontheleft = false;
        boolean selection = Selection; //We also do the selection process here.
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                if (temp2.getLetter() == cursor.getCursor()) {
                    iscursorontheleft = true;
                    break;
                }
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null) {
                        break;
                    }
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true && selection != true) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() != null) {
                    char temp3 = temp2.getRightlink().getLetter();
                    temp2.setLetter(temp3);
                    temp2 = temp2.getRightlink();
                    temp2.setLetter(cursor.getCursor());
                }
            }
            if (iscursorontheleft == true && finding != true && selection != true) {
                char temp3 = temp2.getRightlink().getLetter();
                temp2.getRightlink().setLetter(cursor.getCursor());
                temp2.setLetter(temp3);
            }
            if (selection == true && finding == true && iscursorontheleft != true) {
                temp2 = temp2.getRightlink();
                char temp3 = temp2.getRightlink().getLetter();
                selected += temp3;
                count++;
                temp2.setLetter(temp3);
                temp2.getRightlink().setLetter(cursor.getCursor());

                Editor.cnt.setCursorPosition(66, 19);
                Editor.cnt.output("Selected:");
                Editor.cnt.setCursorPosition(76, 19);
                Editor.cnt.output(selected, Editor.att1);
            }
            if (selection == true && iscursorontheleft == true && finding != true) {
                char temp3 = temp2.getRightlink().getLetter();
                selected += temp3;
                count++;
                temp2.setLetter(temp3);
                temp2.getRightlink().setLetter(cursor.getCursor());

                Editor.cnt.setCursorPosition(66, 19);
                Editor.cnt.output("Selected:");
                Editor.cnt.setCursorPosition(76, 19);
                Editor.cnt.output(selected, Editor.att1);
            }
        }
    }

    public void Cut(Cursor cursor) {
        boolean finding = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null) {
                        break;
                    }
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true) {
                charNode cursorplacement = temp2.getRightlink();//cursor
                for (int i = 0; i < count; i++) {
                    temp2 = temp2.getLeftlink();
                }
                charNode temp3 = temp2;
                temp2.setRightlink(cursorplacement);
                cursorplacement.setLeftlink(temp3);
            }
        }
    }

    public void Paste(Cursor cursor) {
        boolean finding = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null) {
                        break;
                    }
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true) {
                if (temp2.getRightlink().getRightlink() == null) {//Paste operation if the right of the cursor is empty
                    temp2 = temp2.getRightlink();
                    temp2.setLetter(' ');
                    for (int i = 0; i < selected.length(); i++) {
                        charNode newnode = new charNode(selected.charAt(i));
                        temp2.setRightlink(newnode);
                        newnode.setLeftlink(temp2);
                        temp2 = temp2.getRightlink();
                    }
                    addCursor(cursor);
                } else {//paste operation in the middle of the paragraph
                    temp2 = temp2.getRightlink();
                    charNode temp3 = temp2.getRightlink();
                    temp2.setLetter(selected.charAt(0));
                    for (int i = 0; i < selected.length() - 1; i++) {
                        charNode newnode = new charNode(selected.charAt(i + 1));
                        temp2.setRightlink(newnode);
                        newnode.setLeftlink(temp2);
                        temp2 = temp2.getRightlink();
                    }
                    charNode newnode = new charNode(cursor.getCursor());
                    temp2.setRightlink(newnode);
                    newnode.setLeftlink(temp2);
                    temp2 = temp2.getRightlink();
                    temp2.setRightlink(temp3);
                    temp3.setLeftlink(temp2);
                }
            }
        }
    }

    public void Next(Cursor cursor) {
        boolean finding = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null) {
                        break;
                    }
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true) {
                charNode temp3 = temp2.getRightlink().getRightlink();
                temp2.setRightlink(temp3);
                temp3.setLeftlink(temp2);
                if (temp.getDownlink() != null) {
                    temp = temp.getDownlink();
                    charNode temp4 = temp.getRightlink();
                    charNode newnode = new charNode(cursor.getCursor());
                    newnode.setRightlink(temp4);
                    temp4.setLeftlink(newnode);
                    newnode.setLeftparagraphnodelink(temp);
                    temp.setRightlink(newnode);
                }
            }
        }
    }

    public void shiftingUp(Cursor cursor) {
        boolean upboundcontrol = false;
        boolean iscursorontheleft = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            boolean finding = false;
            while (temp != null) {
                temp2 = temp.getRightlink();
                if (temp2.getLetter() == cursor.getCursor()) {
                    iscursorontheleft = true;
                    break;
                }
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null)
                        break;
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true && iscursorontheleft != true) {

                temp2.setRightlink(temp2.getRightlink().getRightlink());
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getRightlink() != null) {
                        temp2.getRightlink().getRightlink().setLeftlink(temp2.getRightlink().getLeftlink());
                    }
                }
                for (int i = 0; i < 55; i++) {
                    temp2 = temp2.getLeftlink();
                    if (temp2.getLeftlink() == null) {
                        upboundcontrol = true;
                        break;
                    }
                }
                if (upboundcontrol == false) {
                    charNode newnode = new charNode(cursor.getCursor());
                    charNode temp3 = temp2.getLeftlink();
                    temp2.setLeftlink(newnode);
                    newnode.setRightlink(temp2);
                    newnode.setLeftlink(temp3);
                    temp3.setRightlink(newnode);
                } else {
                    temp2 = temp.getRightlink();
                    while (temp2.getRightlink() != null) {
                        if (cursor.getCursor() == temp2.getRightlink().getLetter()) {
                            temp2.setRightlink(temp2.getRightlink().getRightlink());
                            temp2.getRightlink().setLeftlink(temp2);
                        } else {
                            temp2 = temp2.getRightlink();
                        }
                    }
                    temp = temp.getUplink();
                    temp2 = temp.getRightlink();
                    while (temp2.getRightlink() != null) {
                        temp2 = temp2.getRightlink();
                    }
                    charNode newnode = new charNode(cursor.getCursor());
                    temp2.setRightlink(newnode);
                }
            }
            if (iscursorontheleft == true && finding != true) {
                ParagraphNode temp3 = temp2.getLeftparagraphnodelink();
                if (temp3.getUplink() != null) {
                    temp3.setRightlink(temp2.getRightlink());
                    temp2.getRightlink().setLeftparagraphnodelink(temp3);
                    temp3 = temp3.getUplink();
                    temp2 = temp3.getRightlink();
                    while (temp2.getRightlink() != null) {
                        temp2 = temp2.getRightlink();
                    }
                    charNode newnode = new charNode(cursor.getCursor());
                    temp2.setRightlink(newnode);
                    newnode.setLeftlink(temp2);
                }
            }
        }
    }

    public void shiftingDown(Cursor cursor) {
        boolean downboundcontrol = false;//we check for paragraph replacement
        boolean iscursorontheleft = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            boolean finding = false;
            while (temp != null) {
                temp2 = temp.getRightlink();
                if (temp2.getLetter() == cursor.getCursor()) {
                    iscursorontheleft = true;
                    break;
                }
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null)
                        break;
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true && iscursorontheleft != true) {
                temp2.setRightlink(temp2.getRightlink().getRightlink());
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getRightlink() != null) {
                        temp2.getRightlink().getRightlink().setLeftlink(temp2.getRightlink().getLeftlink());
                    }
                }
                for (int i = 0; i < 55; i++) {
                    temp2 = temp2.getRightlink();
                    if (temp2 != null) {
                        if (temp2.getRightlink() == null) {
                            downboundcontrol = true;
                            break;
                        }
                    }
                }
                if (downboundcontrol == false) {
                    charNode newnode = new charNode(cursor.getCursor());
                    charNode temp3 = temp2.getRightlink();
                    temp2.setRightlink(newnode);
                    newnode.setLeftlink(temp2);
                    if (temp3 != null) {
                        newnode.setRightlink(temp3);
                        temp3.setLeftlink(newnode);
                    }
                } else {
                    temp2 = temp.getRightlink();
                    while (temp2.getRightlink() != null) {
                        if (cursor.getCursor() == temp2.getRightlink().getLetter()) {
                            temp2.setRightlink(null);
                        } else {
                            temp2 = temp2.getRightlink();
                        }
                    }
                    temp = temp.getDownlink();
                    if (temp != null) {
                        temp2 = temp.getRightlink();
                        charNode previous = temp2.getRightlink();
                        charNode newnode = new charNode(cursor.getCursor());
                        temp2.setRightlink(newnode);
                        newnode.setRightlink(previous);
                        newnode.setLeftlink(temp2);
                        previous.setLeftlink(newnode);
                    }
                }
            }
            if (iscursorontheleft == true && finding != true) {
                ParagraphNode temp3 = temp2.getLeftparagraphnodelink();
                temp3.setRightlink(temp2.getRightlink());
                temp2.getRightlink().setLeftparagraphnodelink(temp3);
                temp2 = temp3.getRightlink();

                for (int i = 0; i < 55; i++) {
                    temp2 = temp2.getRightlink();
                }
                charNode newnode = new charNode(cursor.getCursor());
                charNode temp4 = temp2.getRightlink();
                temp2.setRightlink(newnode);
                newnode.setLeftlink(temp2);
                newnode.setRightlink(temp4);
                temp4.setLeftlink(newnode);
            }
        }
    }

    public void backSpaceChar(Cursor cursor) {
        ParagraphNode temp = head;
        boolean finding = false;
        boolean iscursorontheleft = false;
        charNode temp2 = null;
        while (temp != null) {
            temp2 = temp.getRightlink();
            if (temp2.getLetter() == cursor.getCursor()) {
                iscursorontheleft = true;
                break;
            }
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null)
                    break;
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
        }
        if (finding == true && iscursorontheleft != true) {

            temp2.getLeftlink().setRightlink(temp2.getRightlink());
            temp2.getRightlink().setLeftlink(temp2.getLeftlink());
        }
        if (iscursorontheleft == true && finding != true) {
            ParagraphNode temp3 = temp2.getLeftparagraphnodelink();
            if (temp3.getUplink() != null) {
                temp3.setRightlink(temp2.getRightlink());
                temp2.getRightlink().setLeftparagraphnodelink(temp3);
                temp3 = temp3.getUplink();
                temp2 = temp3.getRightlink();
                while (temp2.getRightlink() != null) {
                    temp2 = temp2.getRightlink();
                }
                charNode newnode = new charNode(cursor.getCursor());
                temp2.setRightlink(newnode);
                newnode.setLeftlink(temp2);
            }
        }
    }

    public void deleteChar(Cursor cursor) {
        ParagraphNode temp = head;
        boolean finding = false;
        charNode temp2 = null;
        while (temp != null) {
            temp2 = temp.getRightlink();
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null)
                    break;
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
        }
        if (finding == true) {

            temp2 = temp2.getRightlink();
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getRightlink() != null) {
                    temp2.setRightlink(temp2.getRightlink().getRightlink());
                    if (temp2.getRightlink() != null) {
                        if (temp2.getRightlink().getRightlink() != null) {
                            if (temp2.getRightlink().getRightlink().getLeftlink() != null) {
                                temp2.getRightlink().getRightlink().setLeftlink(temp2.getRightlink().getLeftlink());
                            }
                        }
                    }
                }
            }
        }
    }

    public void enteringCharr(Cursor cursor, char addData) {
        boolean finding = false;
        ParagraphNode temp = head;
        charNode temp2 = null;
        while (temp != null) {

            temp2 = temp.getRightlink();
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null) {
                    break;
                }
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
        }
        if (finding == true) {
            charNode previous = temp2.getRightlink();
            charNode newnode = new charNode(addData);
            temp2.setRightlink(newnode);
            newnode.setRightlink(previous);
            newnode.setLeftlink(temp2);
            previous.setLeftlink(newnode);
        }
    }

    public void Find(Cursor cursor, String findword) {
        int count = 0;
        int i = 0;
        boolean finding = false;
        boolean temp2null = false;
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (count != findword.length()) {
                    if (findword.charAt(i) == temp2.getLetter()) {
                        count++;
                        temp2 = temp2.getRightlink();
                        i++;
                    } else {
                        if (temp2 != null) {
                            while (temp2.getLetter() != ' ') {
                                temp2 = temp2.getRightlink();
                                if (temp2 == null) {
                                    temp2null = true;
                                    break;
                                }
                            }
                            if (temp2 != null)
                                temp2 = temp2.getRightlink();
                            i = 0;
                        }
                    }
                    if (temp2null == true)
                        break;
                    if (count == findword.length())
                        finding = true;

                    if (count == findword.length())
                        finding = true;
                    if (temp2null == true)
                        break;
                }
                if (finding == true)
                    break;
                temp2null = false;
                count = 0;
                i = 0;
                temp = temp.getDownlink();
            }

            if (finding == true) {
                Editor.cnt.setCursorPosition(66, 22);
                System.out.println("Finding true!");
            } else {
                Editor.cnt.setCursorPosition(66, 22);
                System.out.println("              ");
                Editor.cnt.setCursorPosition(66, 22);
                System.out.println("Finding false!");
                Editor.cnt.setCursorPosition(66, 23);
                System.out.println("         ");
            }
        }
    }
    public void Replace(Cursor cursor, String replaceWord, String findword) {
        int count = 0;
        int i = 0;
        boolean finding = false;
        boolean temp2null = false;
        ParagraphNode temp = head;
        charNode temp2 = null;
        int count2 = 0;
        while (temp != null) {
            temp2 = temp.getRightlink();
            while (count != findword.length()) {
                if (findword.charAt(i) == temp2.getLetter()) {
                    count++;
                    temp2 = temp2.getRightlink();
                    i++;
                } else {
                    if (temp2 != null) {
                        while (temp2.getLetter() != ' ') {
                            temp2 = temp2.getRightlink();
                            if (temp2 == null) {
                                temp2null = true;
                                break;
                            }
                        }
                        if (temp2 != null)
                            temp2 = temp2.getRightlink();
                        i = 0;
                    }
                }
                if (temp2null == true)
                    break;
                if (count == findword.length()) {
                    finding = true;
                    break;
                }
                if (count == findword.length()) {
                    finding = true;
                    break;
                }
                if (temp2null == true)
                    break;
            }
            if (finding == true)
                break;
            temp2null = false;
            count = 0;
            i = 0;
            temp = temp.getDownlink();
        }
        if (finding == true) {
            while (count2 != count) {
                temp2 = temp2.getLeftlink();
                count2++;
            }
            int k = 0;
            if (findword.length() == replaceWord.length() || findword.length() < replaceWord.length()) {
                if (temp2.getLetter() == ' ')
                    temp2 = temp2.getRightlink();
                while (temp2.getLetter() != ' ') {
                    temp2.setLetter(replaceWord.charAt(k));
                    k++;
                    temp2 = temp2.getRightlink();
                }
                if (k != replaceWord.length()) {
                    if (temp2.getLetter() == ' ')
                        temp2 = temp2.getLeftlink();

                    while (k != replaceWord.length()) {

                        charNode temp3 = temp2.getRightlink();
                        charNode newnode = new charNode(replaceWord.charAt(k));
                        temp2.setRightlink(newnode);
                        newnode.setLeftlink(temp2);
                        newnode.setRightlink(temp3);
                        temp3.setLeftlink(newnode);
                        temp2 = temp2.getRightlink();
                        k++;

                    }
                }
            } else if (findword.length() > replaceWord.length()) {
                if (temp2.getLetter() == ' ')
                    temp2 = temp2.getRightlink();
                while (k != replaceWord.length()) {
                    temp2.setLetter(replaceWord.charAt(k));
                    k++; //k= 5
                    temp2 = temp2.getRightlink();
                }
                temp2 = temp2.getLeftlink();
                charNode tempp2 = temp2;
                while (k != findword.length() + 1) {
                    temp2 = temp2.getRightlink();
                    k++;
                }
                tempp2.setRightlink(temp2);
                temp2.setLeftlink(tempp2);
            }
        }
    }

    public void Enter(Cursor cursor) {
        ParagraphNode temp = head;
        boolean finding = false;
        charNode temp2 = null;
        while (temp != null) {
            temp2 = temp.getRightlink();
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null)
                    break;
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
        }
        if (finding == true) {
            if (temp.getDownlink() == null) {
                if (temp2.getRightlink().getRightlink() == null) {
                    temp2.setRightlink(null);
                    addParagraph(temp.getParagraphNumber() + 1);
                    temp = temp.getDownlink();
                    addLetter(temp.getParagraphNumber(),cursor.getCursor());
                } else {
                    int count = 0;
                    addParagraph(temp.getParagraphNumber() + 1);
                    temp = temp.getDownlink();
                    while (temp2.getRightlink() != null) {
                        addLetter(temp.getParagraphNumber(), temp2.getRightlink().getLetter());
                        temp2 = temp2.getRightlink();
                        count++;
                    }
                    for (int i = 0; i < count + 1; i++) {
                        temp2 = temp2.getLeftlink();
                    }
                    temp2.setRightlink(null);
                }
            } else {
                ParagraphNode temp3 = temp.getDownlink();
                ParagraphNode newnode = new ParagraphNode(temp.getParagraphNumber() + 1);
                temp3.setParagraphNumber(newnode.getParagraphNumber() + 1);
                newnode.setUplink(temp);
                temp.setDownlink(newnode);
                newnode.setDownlink(temp3);
                temp3.setUplink(newnode);

                while (temp3.getDownlink() != null) {
                    temp3.getDownlink().setParagraphNumber(temp3.getParagraphNumber() + 1);
                    temp3 = temp3.getDownlink();
                }
                int count = 0;
                temp = temp.getDownlink();
                while (temp2.getRightlink() != null) {
                    addLetter(temp.getParagraphNumber(), temp2.getRightlink().getLetter());
                    temp2 = temp2.getRightlink();
                    count++;
                }
                for (int i = 0; i < count + 1; i++) {
                    temp2 = temp2.getLeftlink();
                }
                temp2.setRightlink(null);
            }
        }
    }

    public void overwrite(Cursor cursor, char addData) {
        if (head == null) {
            System.out.println("Add a paragraph before letter");
        } else {
            ParagraphNode temp = head;
            charNode temp2 = null;
            boolean finding = false;
            while (temp != null) {
                temp2 = temp.getRightlink();
                while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                    temp2 = temp2.getRightlink();
                    if (temp2.getRightlink() == null)
                        break;
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (temp2.getRightlink() != null) {
                    if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                        finding = true;
                        break;
                    }
                }
                if (finding == false) {
                    temp = temp.getDownlink();
                }
            }
            if (finding == true) {
                /*System.out.println(temp2);*/
                temp2 = temp2.getRightlink();
                temp2.setLetter(addData);
                temp2.getRightlink().setLetter(cursor.getCursor());
            }
        }
    }

    public void Home(Cursor cursor) {
        boolean finding = false;
        ParagraphNode temp = head;
        charNode temp2 = null;
        charNode temp4 = null;
        while (temp != null) {
            temp2 = temp.getRightlink();
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null) {
                    break;
                }
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
        }
        if (finding == true) {


            charNode next = temp2.getRightlink().getRightlink();
            temp2.setRightlink(next);
            next.setLeftlink(temp2);
            while (temp2.getLinenumber() == temp2.getLeftlink().getLinenumber())// {
                temp2 = temp2.getLeftlink();
            temp2 = temp2.getLeftlink(); //f
            charNode temp2left = temp2.getLeftlink();
            charNode newnode = new charNode(cursor.getCursor());//temp2 = f
            temp2.setLeftlink(newnode);
            newnode.setRightlink(temp2);
            temp2.getLeftlink().setLeftlink(newnode);
            newnode.setLeftlink(temp2left);
            temp2left.setRightlink(newnode);
        }
    }

    public void End(Cursor cursor) {
        boolean finding = false;
        ParagraphNode temp = head;
        charNode temp2 = null;
        charNode temp4 = null;
        while (temp != null) {
            temp2 = temp.getRightlink();
            while (temp2.getRightlink().getLetter() != cursor.getCursor()) {
                temp2 = temp2.getRightlink();
                if (temp2.getRightlink() == null) {
                    break;
                }
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (temp2.getRightlink() != null) {
                if (temp2.getRightlink().getLetter() == cursor.getCursor()) {
                    finding = true;
                    break;
                }
            }
            if (finding == false)
                temp = temp.getDownlink();
        }
        if (finding == true) {

            charNode next = temp2.getRightlink().getRightlink();
            temp2.setRightlink(next);
            next.setLeftlink(temp2);

            while (temp2.getLinenumber() == temp2.getRightlink().getLinenumber())
                temp2 = temp2.getRightlink();
            charNode temp2right = temp2.getRightlink();
            charNode newnode = new charNode(cursor.getCursor());
            temp2.setRightlink(newnode);
            newnode.setLeftlink(temp2);
            temp2right.setLeftlink(newnode);
            newnode.setRightlink(temp2right);

        }
    }
}