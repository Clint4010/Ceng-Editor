public class ParagraphNode {

    private int paragraphNumber;
    private ParagraphNode downlink;
    private ParagraphNode uplink;
    private charNode rightlink;
    private int[] lines;

    public ParagraphNode(int datatoAdd) {
        paragraphNumber=datatoAdd;
        downlink = null;
        uplink = null;
        rightlink = null;
        lines=new int[1000];
    }

    public int getParagraphNumber() { return paragraphNumber; }

    public void setParagraphNumber(int paragraphNumber) { this.paragraphNumber = paragraphNumber; }

    public ParagraphNode getDownlink() { return downlink; }

    public void setDownlink(ParagraphNode downlink) { this.downlink = downlink; }

    public ParagraphNode getUplink() { return uplink; }

    public void setUplink(ParagraphNode uplink) { this.uplink = uplink; }

    public charNode getRightlink() { return rightlink; }

    public void setRightlink(charNode rightlink) { this.rightlink = rightlink; }

    public int[] getLines() {
        return lines;
    }

    public void setLines(int[] lines) {
        this.lines = lines;
    }
}