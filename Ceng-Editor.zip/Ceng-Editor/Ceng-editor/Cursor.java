public class Cursor {

    private int px;
    private int py;
    private char cursor;


    public Cursor(int px, int py) {

        this.px = px;
        this.py = py;

    }
    public Cursor(int px, int py,char cursor){
        this.px = px;
        this.py = py;
        this.cursor=cursor;
    }

    public char getCursor() {
        return cursor;
    }

    public void setCursor(char cursor) {
        this.cursor = cursor;
    }

    public int getPx() {
        return px;
    }

    public void setPx(int px) {
        this.px = px;
    }

    public int getPy() {
        return py;
    }

    public void setPy(int py) {
        this.py = py;
    }





}